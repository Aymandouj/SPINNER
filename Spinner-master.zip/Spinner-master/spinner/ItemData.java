package ma.projet.android.spinner;

public class ItemData {
    String name;
    int image;
    String Details;

    public ItemData(String name, int image, String details) {
        this.name = name;
        this.image = image;
        Details = details;
    }
}
